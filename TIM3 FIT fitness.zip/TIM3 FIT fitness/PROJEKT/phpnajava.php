<?php

define('DB_NAME', 'projekt');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if(!$link) {
	die ('Could not connect:' . mysql_error());
}

$db_selected = mysql_select_db(DB_NAME, $link);

if (!$db_selected) {
	die('cant use' . DB_NAME. ': ' .mysql_error());
}

if(isset($_POST['submit']))
$value = $_POST['firstname'];
$value2 = $_POST['datum'];
$newDate = date("Y-m-d", strtotime($value2));
$value3 = $_POST['time'];

$sql = "INSERT INTO najavljeni (firstname, datum, vrijeme) VALUES ('$value', '$newDate', '$value3')";

if (!mysql_query($sql)){
	die('Error: ' . mysql_error());
}


header("Location: pocetna2.html");

?>