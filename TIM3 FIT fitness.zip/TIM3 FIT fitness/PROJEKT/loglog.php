<?php

define('DB_NAME', 'projekt');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if(!$link) {
	die ('Could not connect:' . mysql_error());
}

$db_selected = mysql_select_db(DB_NAME, $link);

if (!$db_selected) {
	die('cant use' . DB_NAME. ': ' .mysql_error());
}
session_start();

$username = $_POST['firstname'];
$password = $_POST['psw'];

$admin = 'admin';
$pass = 'admin';

$prazno='';

$username = stripcslashes($username);
$password = stripcslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

$result = mysql_query("select * from korisnici where firstname = '$username' and psw = '$password'")
or die ("Failed to query database ".mysql_error());
$korisnici = mysql_fetch_array($result);
if ($korisnici['firstname'] == $username && $korisnici['psw'] == $password && $korisnici['firstname'] != $prazno){
	session_regenerate_id();
	echo "Login successful! Welcome ".$korisnici['firstname'];
	 $_SESSION['sess_id'] = $korisnici['id'];
	 session_write_close();
} else {
	echo "Failed to login!";
	exit;
}


if($korisnici['firstname'] == $admin && $korisnici['psw'] == $password){
header("Location: pocetnaadmin.html");}
else{
header("Location: pocetna2.html");}
?>