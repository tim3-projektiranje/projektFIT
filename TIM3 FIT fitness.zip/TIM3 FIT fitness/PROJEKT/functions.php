<?php

define('DB_NAME', 'projekt');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if(!$link) {
	die ('Could not connect:' . mysql_error());
}

$db_selected = mysql_select_db(DB_NAME, $link);

if (!$db_selected) {
	die('cant use' . DB_NAME. ': ' .mysql_error());
}

function getId($firstname)
{
	$q = mysql_query(" SELECT id FROM korisnici WHERE firstname = ".$firstname."'");
	while($r = mysql_fetch_assoc($q))
	{
		return $r['id'];
	}
}

function getUsersData($id)
{
	$array = array();
	$q = mysql_query("SELECT * FROM korisnici WHERE 'id' = ".$id);
	while ($r = mysql_fetch_assoc($q))
	{
		$array['id'] = $r['id'];
		$array['firstname'] = $r['firstname'];
		$array['email'] = $r['email'];
		$array['bday'] = $r['bday'];
	}
	return $array;
}


?>