<?php
define('DB_NAME', 'projekt');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');

$link = mysql_connect(DB_HOST, DB_USER, DB_PASSWORD);

if(!$link) {
	die ('Could not connect:' . mysql_error());
}

$db_selected = mysql_select_db(DB_NAME, $link);

if (!$db_selected) {
	die('cant use' . DB_NAME. ': ' .mysql_error());
}
session_start();

$id = $_SESSION['sess_id'];
$result3 = mysql_query("SELECT * FROM korisnici where id='$id'");
while($row3 = mysql_fetch_array($result3))
{ 
$fname=$row3['firstname'];
$lname=$row3['bday'];
$address=$row3['email'];
}
echo "\n\32";
?>

<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="css/styles.css">
<title>Profil</title>

</head>

<body bgcolor="#44b3c2">
<p id="prijavasign" >Tvoj Profil</p> <br><br><br><br>
<p class="prijavakuc3"> <?php echo $fname; ?></p>
<p class="prijavakuc3"> <?php echo $lname; ?></p>
<p class="prijavakuc3"> <?php echo $address; ?></p>
<br><br><br>
<img src="img/prijavadole.jpg" id="onamadole">



</body>
</html>