-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 02, 2017 at 06:32 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `korisnici`
--

CREATE TABLE `korisnici` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `psw` varchar(1000) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `bday` date NOT NULL,
  `idnaj` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `korisnici`
--

INSERT INTO `korisnici` (`id`, `firstname`, `psw`, `email`, `bday`, `idnaj`) VALUES
(9, 'admin', 'admin', 'admin@gmail.com', '1995-03-31', NULL),
(10, 'Mario Maric', 'mar', 'mariomar@gmail.com', '1990-03-31', NULL),
(11, 'jedandva', '1', 'jedan@gmail.com', '1999-03-11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `najavljeni`
--

CREATE TABLE `najavljeni` (
  `idnaj` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `datum` date NOT NULL,
  `vrijeme` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `najavljeni`
--

INSERT INTO `najavljeni` (`idnaj`, `firstname`, `datum`, `vrijeme`) VALUES
(1, '', '1970-01-01', '00:00:00'),
(2, '', '1970-01-01', '00:00:00'),
(3, 'mario maric', '2014-03-11', '12:33:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idnaj` (`idnaj`);

--
-- Indexes for table `najavljeni`
--
ALTER TABLE `najavljeni`
  ADD PRIMARY KEY (`idnaj`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `korisnici`
--
ALTER TABLE `korisnici`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `najavljeni`
--
ALTER TABLE `najavljeni`
  MODIFY `idnaj` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `korisnici`
--
ALTER TABLE `korisnici`
  ADD CONSTRAINT `korisnici_ibfk_1` FOREIGN KEY (`idnaj`) REFERENCES `najavljeni` (`idnaj`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
